/*$('.input-number-increment').click(function() {
  var $input = $(this).parents('.input-number-group').find('.input-number');
  var val = parseInt($input.val(), 10);
  $input.val(val + 1);
});

$('.input-number-decrement').click(function() {
  var $input = $(this).parents('.input-number-group').find('.input-number');
  var val = parseInt($input.val(), 10);
  $input.val(val - 1);
});

*/

function getDepart() {
  xhr = new XMLHttpRequest();
  xhr.onload = function() {
    var response = JSON.parse(this.responseText);
    for(i=0;i<100;i++) {
      var course = response.nowCourse[i].課程名稱;
      var serial = response.nowCourse[i].課程碼;
      var teacher = response.nowCourse[i].老師;
      var div = document.createElement('div');
      div.className = "courseList__sideList__itemBox__item";
      var div2 = document.createElement('div');
      div2.className = "courseText";
      var p1 = document.createElement('p');
      var p2 = document.createElement('p');
      var circle = document.createElement('div');
      circle.className = "circle";

      document.getElementById("course_item").appendChild(div);
      div.appendChild(circle);
      div.appendChild(div2);
      div2.appendChild(p1);
      div2.appendChild(p2);

      p1.innerHTML = course;
      p2.innerHTML = serial + " - " + teacher;

    }

  }
  xhr.open('GET', 'https://nckuhub.com/course/allcourse', true)
  xhr.send()
}
getDepart();



function dropdownFunction() {
  document.getElementById("dropdown1").classList.toggle("show");
}

var course_data = [
	{
		'name': '微積分1（一）',
		'department': '工資系',
		'serial': 'H3005',
		'teacher': '侯世章',
    'time': '[3]5-6、[5]7-8',
    'lecture': '講授50%、看影片50%',
    'score': '報告25%、作業25%、簽到50%'
	},
	{
		'name': '微積分2（一）',
		'department': '工資系',
		'serial': 'H3005',
		'teacher': '侯世章',
    'time': '[3]5-6、[5]7-8',
    'lecture': '講授50%、看影片50%',
    'score': '報告25%、作業25%、簽到50%'
	},
	{
		'name': '微積分3（一）',
		'department': '工資系',
		'serial': 'H3005',
		'teacher': '侯世章',
    'time': '[3]5-6、[5]7-8',
    'lecture': '講授50%、看影片50%',
    'score': '報告25%、作業25%、簽到50%'
	},
	{
		'name': '微積分4（一）',
		'department': '工資系',
		'serial': 'H3005',
		'teacher': '侯世章',
    'time': '[3]5-6、[5]7-8',
    'lecture': '講授50%、看影片50%',
    'score': '報告25%、作業25%、簽到50%'
	},
		{
		'name': '微積分5（一）',
		'department': '工資系',
		'serial': 'H3005',
		'teacher': '侯世章',
    'time': '[3]5-6、[5]7-8',
    'lecture': '講授50%、看影片50%',
    'score': '報告25%、作業25%、簽到50%'
	},
	{
		'name': '微積分6（一）',
		'department': '工資系',
		'serial': 'H3005',
		'teacher': '侯世章',
    'time': '[3]5-6、[5]7-8',
    'lecture': '講授50%、看影片50%',
    'score': '報告25%、作業25%、簽到50%'
	},
  {
		'name': '微積分6（一）',
		'department': '工資系',
		'serial': 'H3005',
		'teacher': '侯世章',
    'time': '[3]5-6、[5]7-8',
    'lecture': '講授50%、看影片50%',
    'score': '報告25%、作業25%、簽到50%'
	},
  {
		'name': '微積分6（一）',
		'department': '工資系',
		'serial': 'H3005',
		'teacher': '侯世章',
    'time': '[3]5-6、[5]7-8',
    'lecture': '講授50%、看影片50%',
    'score': '報告25%、作業25%、簽到50%'
	},
  {
		'name': '微積分6（一）',
		'department': '工資系',
		'serial': 'H3005',
		'teacher': '侯世章',
    'time': '[3]5-6、[5]7-8',
    'lecture': '講授50%、看影片50%',
    'score': '報告25%、作業25%、簽到50%'
	},
  {
		'name': '微積分6（一）',
		'department': '工資系',
		'serial': 'H3005',
		'teacher': '侯世章',
    'time': '[3]5-6、[5]7-8',
    'lecture': '講授50%、看影片50%',
    'score': '報告25%、作業25%、簽到50%'
	},
  {
		'name': '微積分6（一）',
		'department': '工資系',
		'serial': 'H3005',
		'teacher': '侯世章',
    'time': '[3]5-6、[5]7-8',
    'lecture': '講授50%、看影片50%',
    'score': '報告25%、作業25%、簽到50%'
	}
];


$(document).ready(function(){

  var vue_course_item = new Vue({
    el: '#course_item',
    data: {
      course_data: course_data,
      heartColor: false,
    },
    methods: {
      courseLink: function(index) {
        vue_courseContent.isShow = true;
        vue_courseContent.course_data1 = course_data[index];

      },

      changeHeartColor: function(index){
        if(vue_course_item.heartColor == false) {
          vue_course_item.heartColor = true;
        } else {
          vue_course_item.heartColor = false;
        }
      },
      addCourse: function(index){
        console.log(index);
        var chooseCourse = vue_course_item.course_data[index];
        console.log(chooseCourse);
        vue_wishList.wishList.push(chooseCourse);
        console.log(vue_wishList.wishList);
      }
    }
  })

  var vue_courseContent = new Vue ({
    el: '#courseContent',
    data: {
      isShow: false,
      course_data1 : course_data
    },
    methods: {
      showContent: function() {
        vue_courseContent.isShow = false;
      }
    }
  })

  var vue_wishList = new Vue ({
    el: '#wishList',
    data: {
      wishList: [],
    }
  })

});
